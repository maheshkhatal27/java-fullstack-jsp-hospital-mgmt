package com.springjdbc.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.springjdbc.model.Patient;

public class PatientDAOTest {
	
	private DriverManagerDataSource dataSource;
	private PatientDAO dao;

	@Before
	public void setupBeforeEach(){
		dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		dataSource.setUrl("jdbc:mysql://localhost:3306/hms");
		dataSource.setUsername("root");
		dataSource.setPassword("root");
		
		dao = new PatientDAOImpl(dataSource);
	}
	
	@Test
	public void testSave() {
//		dataSource = new DriverManagerDataSource();
//		dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
//		dataSource.setUrl("jdbc:mysql://localhost:3306/hms");
//		dataSource.setUsername("root");
//		dataSource.setPassword("root");
//		
//		dao = new PatientDAOImpl(dataSource);
		
		Patient p = new Patient("Aarcus Harris","AB+ve","NA");
		int result = dao.save(p);
		assertTrue(result > 0);
	}

	@Test
	public void testUpdate() {
		Patient p = new Patient(121,"Jacob Marlow","B+ve","Corona");
		int result = dao.update(p);
		assertTrue(result > 0);
	}

	@Test
	public void testGet() {
		Integer id =888;
		Patient p = dao.get(id);
		if(p != null){
			System.out.println(p);
		}
		assertNotNull(p);
	}

	@Test
	public void testDelete() {
		Integer id = 151;
		int result = dao.delete(id);
		assertTrue(result > 0);
	}

	@Test
	public void testList() {
		List<Patient> patientList = dao.list();
		for(Patient p : patientList){
			System.out.println(p);
		}
		assertTrue(!patientList.isEmpty());
	}

}
