package com.springjdbc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.springjdbc.model.Patient;

public class PatientDAOImpl implements PatientDAO {
	private JdbcTemplate jdbcTemplate;
	
	public PatientDAOImpl(DataSource dataSource){
		this.jdbcTemplate=new JdbcTemplate(dataSource);
	}
	@Override
	public int save(Patient p) {
		// TODO Auto-generated method stub
		String sql = "insert into patient(idpatient,patientname,bloodgroup,disease) values(?,?,?,?)";
		return jdbcTemplate.update(sql,p.getPatientId(),p.getPatientName(),p.getBloodGroup(),p.getDisease());
	
	}

	@Override
	public int update(Patient p) {
		// TODO Auto-generated method stub
		String sql = "update patient set patientname=?,bloodgroup=?,disease=? where idpatient=?";
		return jdbcTemplate.update(sql,p.getPatientName(),p.getBloodGroup(),p.getDisease(),p.getPatientId());
		
		
	}

	@Override
	public Patient get(Integer id) {
		// TODO Auto-generated method stub
		String sql = "select * from Patient where idpatient="+ id;
		ResultSetExtractor<Patient> extractor = new ResultSetExtractor<Patient>(){

			@Override
			public Patient extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
			   if(rs.next()){
				   int id = rs.getInt("idpatient");
				   String pname = rs.getString("patientname");
				   String bloodgr = rs.getString("bloodgroup");
				   String disease = rs.getString("disease");
				   return new Patient(id,pname,bloodgr,disease);
			   }
				return null;
			}
			
		};
		
		return jdbcTemplate.query(sql, extractor);
	}

	@Override
	public int delete(Integer id) {
		// TODO Auto-generated method stub
		String sql = "delete from patient where idpatient = "+id;
		return jdbcTemplate.update(sql);
		
	}

	@Override
	public List<Patient> list() {
		// TODO Auto-generated method stub
		String sql = "select * from patient";
		RowMapper<Patient> rowMapper = new RowMapper<Patient>(){

			@Override
			public Patient mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
					   int id = rs.getInt("idpatient");
					   String pname = rs.getString("patientname");
					   String bloodgr = rs.getString("bloodgroup");
					   String disease = rs.getString("disease");
					   return new Patient(id,pname,bloodgr,disease);
			}
			
		};
		return jdbcTemplate.query(sql, rowMapper);
		
	}

}
