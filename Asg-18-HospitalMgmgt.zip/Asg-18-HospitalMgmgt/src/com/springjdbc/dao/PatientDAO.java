package com.springjdbc.dao;
import java.util.List;

import com.springjdbc.model.Patient;

public interface PatientDAO {
	public int save(Patient p);
	public int update(Patient p);
	public Patient get(Integer id);
	public int delete(Integer id);
	public List<Patient> list();
}
