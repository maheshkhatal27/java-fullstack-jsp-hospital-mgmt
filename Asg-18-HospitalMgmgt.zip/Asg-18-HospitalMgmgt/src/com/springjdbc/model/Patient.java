package com.springjdbc.model;

public class Patient {

	private int patientId;
	private String patientName;
	private String bloodGroup;
	private String disease;
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getDisease() {
		return disease;
	}
	public void setDisease(String disease) {
		this.disease = disease;
	}
	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Patient(Integer patientId, String patientName, String bloodGroup, String disease) {
		
		this(patientName,bloodGroup,disease);
		this.patientId = patientId;
	}
	
	public Patient(String patientName, String bloodGroup, String disease) {
		
		this.patientName = patientName;
		this.bloodGroup = bloodGroup;
		this.disease = disease;
	}
	
	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", patientName=" + patientName + ", bloodGroup=" + bloodGroup
				+ ", disease=" + disease + "]";
	}
	
	
}
