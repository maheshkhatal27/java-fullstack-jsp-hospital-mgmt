package com.springjdbc.controller;
import com.springjdbc.model.Patient;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.springjdbc.dao.PatientDAO;

@Controller
public class MainController {
	@Autowired
	private PatientDAO p;
	
	@RequestMapping(value="/")
	public ModelAndView listPatient(ModelAndView model){
		List<Patient> listPatient = p.list();
		model.addObject("listPatient",listPatient);
		model.setViewName("index");
		return model;
	}
	
	@RequestMapping(value="/new",method=RequestMethod.GET)
	public ModelAndView newPatient(ModelAndView model){
		Patient patient = new Patient();
		model.addObject("patient",patient);
		model.setViewName("patient_form");
		return model;
	}
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public ModelAndView savePatient(@ModelAttribute Patient patient){
		if(patient.getPatientId() == 0){
			p.save(patient);
			
		}else{
			p.update(patient);
		}
		
		return new ModelAndView("redirect:/");
	}
	
	@RequestMapping(value="/edit",method=RequestMethod.GET)
	public ModelAndView editPatient(HttpServletRequest request){
		Integer id = Integer.parseInt(request.getParameter("id"));
		Patient patient = p.get(id);
		ModelAndView model = new ModelAndView("patient_form");
		model.addObject("patient",patient);
		return model;
	}

	
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public ModelAndView deletePatient(@RequestParam Integer id){
		p.delete(id);
		return new ModelAndView("redirect:/");
	}
	
	

}
